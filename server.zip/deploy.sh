# https://docs.microsoft.com/en-us/azure/developer/javascript/tutorial/deploy-deno-app-azure-app-service-azure-cli
# Setting the commands in this bash file 

# This only needs to be ran for the initial creation of the application
az webapp create -n ansalemo-linux-deno --resource-group ansalemo-rg -p ansalemo-asp-testing -i anthonychu/azure-webapps-deno:1.0.2
az webapp config container set --name ansalemo-linux-deno --resource-group ansalemo-rg -i anthonychu/azure-webapps-deno:1.0.2 -r 'https://index.docker.io' -u '' -p  '' -t true
az webapp config set --name ansalemo-linux-deno --resource-group ansalemo-rg --startup-file ''
az webapp config appsettings set --name ansalemo-linux-deno --resource-group ansalemo-rg --settings WEBSITE_RUN_FROM_PACKAGE=1 WEBSITES_ENABLE_APP_SERVICE_STORAGE=true WEBSITES_PORT=8080

# Deploy the application
az webapp deployment source config-zip --name ansalemo-linux-deno --resource-group ansalemo-rg --src DenoServerAPI.zip
# Set the startup file
az webapp config set --name ansalemo-linux-deno --resource-group ansalemo-rg --startup-file 'deno run --allow-net --allow-read server.ts'